/**
 * @license Copyright (c) 2003-2016, CKSource - Frederico Knabben. All rights reserved.
 * For licensing, see LICENSE.md or http://ckeditor.com/license
 */
CKEDITOR.editorConfig = function( config ) {
	
	// Does not allow FORM content manually pasted into source to remain.
	// https://www.drupal.org/node/1606596
	config.allowedContent = true;
	
	// added 2012-04-13 to not transcode source code when editing embedded scripts
	// in preparation for dynamically-executed -Content.asp files - ele
	config.protectedSource.push( /<\?[\s\S]*?\?>/g );   // PHP code
	config.protectedSource.push( /<%[\s\S]*?%>/g );   // ASP code
	config.protectedSource.push( /(]+>[\s|\S]*?<\/asp:[^\>]+>)|(]+\/>)/gi );   // ASP.Net code
	

	// Define changes to default configuration here. For example:
	// config.language = 'fr';
	// config.uiColor = '#ffe066';
	// config.removeButtons = 'Scayt,Form,Checkbox,Radio,TextField,Textarea,Select,Button,ImageButton,HiddenField';
};
